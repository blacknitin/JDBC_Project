package com.jsp.student_task_curd_operation_servlet.service;

import com.jsp.student_task_curd_operation_servlet.dao.TaskDao;
import com.jsp.student_task_curd_operation_servlet.dto.Task;

public class TaskService {
	TaskDao  dao=new TaskDao();
	public Task saveTaskService(Task task) {
		return dao.saveTaskDao(task);
	}

}
