package com.jsp.student_task_curd_operation_servlet.dto;

import java.time.LocalDate;

public class Task {
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String name;
	private LocalDate date;
	private String taskinfo;
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Task(int id, String name, LocalDate date, String taskinfo) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.taskinfo = taskinfo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTaskinfo() {
		return taskinfo;
	}
	public void setTaskinfo(String taskinfo) {
		this.taskinfo = taskinfo;
	}

}
