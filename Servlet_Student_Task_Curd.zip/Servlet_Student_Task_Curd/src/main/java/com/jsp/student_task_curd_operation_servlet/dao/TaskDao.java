package com.jsp.student_task_curd_operation_servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.jsp.student_task_curd_operation_servlet.connection.TaskStudentConnection;
import com.jsp.student_task_curd_operation_servlet.dto.Student;
import com.jsp.student_task_curd_operation_servlet.dto.Task;

public class TaskDao {
	static Connection connection = TaskStudentConnection.getStudentConnection();
	public Task saveTaskDao(Task task) {

		String insertQuery = "insert into task ( taskname, taskdate, taskinfo) values(?,?,?)";

		try {

			PreparedStatement ps = connection.prepareStatement(insertQuery);
			ps.setString(1, task.getName());
			ps.setObject(2, task.getDate());
			ps.setString(3, task.getTaskinfo());
			ps.execute();

			return task;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	public static List<Task> getAllTaskDao(){
		String selectQuery = "SELECT * FROM task";
		List<Task> tasks = new ArrayList<Task>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				tasks.add(
						new Task(
								resultSet.getInt("taskid"),
								resultSet.getString("taskname"), 
								resultSet.getDate("taskdate").toLocalDate(),  
								resultSet.getString("taskinfo"))
						);
			}
			System.out.println(tasks);
			return tasks;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public int deleteStudentByIdDao(int id) {
		String deleteQuery="delete from task where id=?";
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(deleteQuery);
			preparedStatement.setInt(1, id);
			System.out.println("till working");
			return preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
		
		
	}
	public int updateStudentByIdDao(int id,Task task) {
		String deleteQuery="update task set taskname =?,set taskname =?,set taskdate where taskid=?";
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(deleteQuery);
			ps.setString(1,task.getName());
			ps.setString(2,task.getTaskinfo());
			ps.setObject(3,task.getDate());
			ps.setInt(4,task.getId());
			return ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
}
	public static List<Task> getAllTaskDaoByDate( LocalDate date ){
		String selectQuery = "SELECT * FROM task where taskdate = ?";
		
		List<Task> tasks = new ArrayList<Task>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
			preparedStatement.setObject(1,date );
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				tasks.add(
						new Task(
								resultSet.getInt("taskid"),
								resultSet.getString("taskname"), 
								resultSet.getDate("taskdate").toLocalDate(),  
								resultSet.getString("taskinfo"))
						);
			}
			System.out.println(tasks);
			return tasks;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
