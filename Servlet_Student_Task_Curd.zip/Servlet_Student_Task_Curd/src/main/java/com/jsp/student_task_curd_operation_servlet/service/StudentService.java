package com.jsp.student_task_curd_operation_servlet.service;

import com.jsp.student_task_curd_operation_servlet.dao.StudentDao;
import com.jsp.student_task_curd_operation_servlet.dto.Student;

public class StudentService {
	StudentDao dao=new StudentDao();
	public Student saveStudentService(Student student) {
		return dao.saveStudentDao(student);
	}

}
