package com.jsp.student_task_curd_operation_servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jsp.student_task_curd_operation_servlet.connection.TaskStudentConnection;
import com.jsp.student_task_curd_operation_servlet.dto.Student;



public class StudentDao {
	static Connection connection = TaskStudentConnection.getStudentConnection();

	public Student saveStudentDao(Student student) {

		String insertQuery = "insert into student values(?,?,?,?,?)";

		try {

			PreparedStatement ps = connection.prepareStatement(insertQuery);

			ps.setInt(1, student.getId());
			ps.setString(2, student.getName());
			ps.setString(3, student.getEmail());
			ps.setString(4, student.getPassword());
			ps.setString(5, student.getGender() );
			

			ps.execute();

			return student;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	public static List<Student> getAllStudentDao(){
		String selectQuery = "SELECT * FROM student";
		List<Student> students = new ArrayList<Student>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				students.add(
						new Student(
								resultSet.getInt("studentid"), 
								resultSet.getString("studentname"), 
								resultSet.getString("studentemail"),  
								resultSet.getString("studentpassword"), 
								resultSet.getString("gender"))
						);
			}
			System.out.println(students);
			return students;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static 

}
