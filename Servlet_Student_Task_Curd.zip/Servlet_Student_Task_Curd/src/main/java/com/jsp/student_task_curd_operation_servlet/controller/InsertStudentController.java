package com.jsp.student_task_curd_operation_servlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import com.jsp.student_task_curd_operation_servlet.dto.Student;
import com.jsp.student_task_curd_operation_servlet.service.StudentService;
@WebServlet("/register-student")
public class InsertStudentController implements Servlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		 int id=Integer.parseInt(req.getParameter("studentId"));
	        
	        String name = req.getParameter("studentname");
	        String email = req.getParameter("studentemail");
	        String password = req.getParameter("studentpassword");
	        String gender = req.getParameter("gender");
	        Student student=new Student(id, name, email, password,gender);
	        PrintWriter pw=res.getWriter();
	        StudentService service=new StudentService();
	         service.saveStudentService(student);
	        
	        if(service!=null) {
	        	pw.write("<html><body><h4 style='color:green'>Registered-Successfully</h4></body></html>");
	        }else {
	        	pw.write("<html><body><h4 style='color:red'>Not-Registered</h4></body></html>");
	        }
	       
	       RequestDispatcher dispatcher = req.getRequestDispatcher("register.jsp");
	       dispatcher.include(req, res);
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	

}
